package lecho.lib.hellocharts.model;

public enum ValueShape {
    CIRCLE, SQUARE, DIAMOND
}
