/** Automatically generated file. DO NOT MODIFY */
package com.doublefi123.diary;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}