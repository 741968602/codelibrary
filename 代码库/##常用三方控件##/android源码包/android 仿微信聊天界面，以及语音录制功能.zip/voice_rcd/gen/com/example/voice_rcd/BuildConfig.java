/** Automatically generated file. DO NOT MODIFY */
package com.example.voice_rcd;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}