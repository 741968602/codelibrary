asmack
------

Development of SMACK for Android seems to have fragmented, so there are many
versions.

  asmack-jse.jar
        https://github.com/guardianproject/asmack

Previously, we've used other versions:

  asmack-jse.jar
        https://github.com/rtreffer/asmack

  asmack-android-2.1-beem.jar
        http://dev.beem-project.com/attachments/download/51/asmack-android-2.1-source-beem.zip
  asmack-2010.05.07.jar

