package info.guardianproject.otr;

public class TorProxyInfo {

    public final static String PROXY_TYPE = "SOCKS5";
    public final static String PROXY_HOST = "127.0.0.1";
    public final static int PROXY_PORT = 9050;
}
