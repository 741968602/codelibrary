DelectPullToRefreesh
====================

DelectPullToRefreesh 模仿QQ界面，listview既可以上拉刷新，下拉加载，还可以进行手势滑动listview进行删除操作
![image](https://github.com/soyoungboy/DelectPullToRefreesh-master/blob/master/res/上拉刷新，下拉加载，滑动item可以删除对应item.gif)
欢迎star和fork
