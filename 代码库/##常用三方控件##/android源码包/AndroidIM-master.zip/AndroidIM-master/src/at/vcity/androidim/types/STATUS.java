package at.vcity.androidim.types;

public enum STATUS {
	ONLINE, OFFLINE, BUSY, INVISIBLE, AWAY, UNAPPROVED
}
