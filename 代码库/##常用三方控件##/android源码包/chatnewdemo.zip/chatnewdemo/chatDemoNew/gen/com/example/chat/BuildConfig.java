/** Automatically generated file. DO NOT MODIFY */
package com.example.chat;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}