package com.example.chat;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.widget.Button;

public class MainActivity extends Activity {
	
	private Button send;//发送按钮
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.chat_main);
	}
	private void initViews(){
		send=(Button)findViewById(R.id.send_sms);
		
	}


}
