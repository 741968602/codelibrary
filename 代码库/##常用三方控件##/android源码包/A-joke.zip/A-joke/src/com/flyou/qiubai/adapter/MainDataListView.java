package com.flyou.qiubai.adapter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.content.Context;
import android.widget.Adapter;
import android.widget.SimpleAdapter;

import com.flyou.qiubai.Utils.HttpUtils;

public class MainDataListView {
	public static String text[];
	public static String title[];
	public static String time[];
	public static String num[];
	public Adapter adapter;
	List<Map<String, String>> data;
	Map<String, String> map_data;
	Map<String, String[]> map = null;

	public SimpleAdapter homepageListView(Context context, String path) {
		map = new HttpUtils().GetInfo(path);

		title = map.get("title");
		time = map.get("time");
		num = map.get("num");
		text = map.get("text");

		data = new ArrayList<Map<String, String>>();
		for (int i = 0; i < text.length; i++) {
			map_data = new HashMap<String, String>();
			map_data.put("title", title[i]);
			map_data.put("time", time[i]);
			map_data.put("num", num[i]);
			data.add(map_data);
		}

		adapter = new SimpleAdapter(context, data,
				com.flyou.qiubai.activity.R.layout.main_data_listview,
				new String[] { "title", "time", "num" }, new int[] {
						com.flyou.qiubai.activity.R.id.main_title,
						com.flyou.qiubai.activity.R.id.main_time,
						com.flyou.qiubai.activity.R.id.main_num });
		return (SimpleAdapter) adapter;

	}
}
