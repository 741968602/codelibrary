package com.flyou.qiubai.activity;
import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
public class NewPassActivity extends Activity {
	
	private EditText oldEditText;
	private EditText newEditText;
	private Button passButton;
	private SharedPreferences sp;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.newpass);
		sp = getSharedPreferences("User", Context.MODE_APPEND);
		oldEditText=(EditText)findViewById(R.id.oldpass);
		newEditText=(EditText)findViewById(R.id.newpass);
		passButton=(Button)findViewById(R.id.passbutton);
		
		passButton.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
				String oldp=sp.getString("pass", "");
				String oldpass=oldEditText.getText().toString();
				String newpass=newEditText.getText().toString();
				if("".equals(oldpass)||"".equals(newpass)){
					
					Toast.makeText(NewPassActivity.this, "���벻��Ϊ��", 0).show();
					
				}
				else if(!oldp.equals(oldpass)){
					
					Toast.makeText(NewPassActivity.this, "�����벻��ȷ", 0).show();
					
				}else if(oldp.equals(oldpass)&&!("".equals(oldpass)||"".equals(newpass))){
					
					SharedPreferences.Editor editormark = sp.edit();
					editormark.putString("pass", newpass);
					editormark.commit();
					Toast.makeText(NewPassActivity.this, "�����޸���ȷ", 0).show();
					
				}
			}
		});
		
		
	}
	

}
