package com.flyou.qiubai.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends Activity{
	boolean isFirstIn = false;
	private Button login;
	private EditText edit;
	public static SharedPreferences sp;
	private static final String SHAREDPREFERENCES_NAME = "first_pref";
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.login);
		sp = getSharedPreferences("User", Context.MODE_APPEND);
		edit=(EditText)findViewById(R.id.logintext);
		login=(Button)findViewById(R.id.loginbutton);
		login.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
				String logintextString=edit.getText().toString();
				
				if("".equals(logintextString)){
					
					Toast.makeText(LoginActivity.this, "密码不能为空", 0).show();
					init();
				}
				init();
				
			}
		});
		
	}
	
	
	private void init() {

		// 取得相应的值，如果没有该值，说明还未写入，用true作为默认值ֵ
		SharedPreferences preferences = getSharedPreferences(SHAREDPREFERENCES_NAME, MODE_PRIVATE);

		// 取得相应的值，如果没有该值，说明还未写入，用true作为默认值ֵ
		isFirstIn = preferences.getBoolean("isFirstIn", true);

		// 判断程序与第几次运行，如果是第一次运行则跳转到引导界面，否则跳转到主界面
		if (isFirstIn) {
			Toast.makeText(LoginActivity.this, "初始密码为123请在设置中修改", 0).show();
	        Editor editor = preferences.edit();
	        // 存入数据
	        editor.putBoolean("isFirstIn", false);
	        // 提交修改
	        editor.commit();
			SharedPreferences.Editor editormark = sp.edit();
			editormark.putString("pass", "123");
			editormark.commit();
			
			
		} 
		else{
			String passwardString=sp.getString("pass", "");
			String logintextString=edit.getText().toString();
			if(!passwardString.equals(logintextString)){
				Toast.makeText(LoginActivity.this, "密码错误", 0).show();
				
			}else{
				
				Intent intent=new Intent(LoginActivity.this,MainActivity.class);
				startActivity(intent);
				
			}
		}

	}

}
