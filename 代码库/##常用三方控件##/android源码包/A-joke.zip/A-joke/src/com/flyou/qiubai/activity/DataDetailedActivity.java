package com.flyou.qiubai.activity;

import com.zdp.aseo.content.AseoZdpAseo;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.webkit.WebView;
import android.widget.TextView;

public class DataDetailedActivity extends Activity {
	private TextView titleView;
	private WebView mywebView;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		 setTitle("Ц������");  
		    setContentView(R.layout.activity_main);  
		    ActionBar actionBar = getActionBar();  
		    actionBar.setDisplayHomeAsUpEnabled(true); 
		super.setContentView(R.layout.data_detailed);
		init();
	}

	private void init() {
		// TODO Auto-generated method stub
		// �ð�ťʵ�ַ��ؼ��Ĺ���
		AseoZdpAseo.initType(this, AseoZdpAseo.INSERT_TYPE);
		titleView = (TextView) this.findViewById(R.id.data_derailed_title);
		mywebView = (WebView) this.findViewById(R.id.data_derailed_webView);
		// ��������Ĭ��Ϊutf-8����
		mywebView.getSettings().setDefaultTextEncodingName("UTF-8");
		
		mywebView.setBackgroundColor(Color.parseColor("#FFFFCC"));
		mywebView.getSettings().setBuiltInZoomControls(true);
		// mywebView.getSettings().setSupportZoom(true);
		Intent intent = getIntent();
		String title = intent.getStringExtra("title");
		String info = intent.getStringExtra("dataText");
		String htmlString = info.substring(19, info.length() - 7);
		titleView.setText(title);
		mywebView.loadData(htmlString, "text/html; charset=UTF-8", "UTF-8");
		
	}
	@Override
	public void onOptionsMenuClosed(Menu menu) {
		// TODO Auto-generated method stub
		getMenuInflater().inflate(R.menu.main, menu);
		super.onOptionsMenuClosed(menu);
	}
	public boolean onOptionsItemSelected(MenuItem item) {  
	    switch (item.getItemId()) {  
	    case android.R.id.home:  
	        finish();  
	       
	    
	    }
		return false;  
	}  
}
