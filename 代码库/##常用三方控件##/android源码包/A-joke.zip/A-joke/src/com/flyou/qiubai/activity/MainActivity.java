package com.flyou.qiubai.activity;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.AdapterContextMenuInfo;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import com.flyou.qiubai.Utils.DelHtmlTags;
import com.flyou.qiubai.Utils.HttpUtils;
import com.flyou.qiubai.adapter.MainDataListView;
import com.zdp.aseo.content.AseoZdpAseo;

public class MainActivity extends Activity {
	private ListView MainListView;
	private SimpleAdapter mainSimpleAdapter;
	private SlidingLayout slidingLayout;
	ProgressDialog dialog;
    private Button exitbutton,newpassbutton,weather;//---退出
    
    public static SharedPreferences sp;//轻型数据存储密码
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		sp = getSharedPreferences("User", Context.MODE_APPEND);//获得密码储存文件
		newpassbutton=(Button)findViewById(R.id.newpassbutton);//密码设置界面
		newpassbutton.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
				Intent intent=new Intent(MainActivity.this,NewPassActivity.class);
				startActivity(intent);
				
				
			}
		});
		weather=(Button)findViewById(R.id.weather);//密码设置界面
		weather.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
				Intent intent=new Intent(MainActivity.this,Weather.class);
				startActivity(intent);
				
				
			}
		});
		////////////
		exitbutton=(Button)this.findViewById(R.id.exitbutton);//退出按钮---
		exitbutton.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
				builder.setTitle("是否退出？");
				builder.setMessage("确定要退出吗");
				builder.setPositiveButton("是",
						new android.content.DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface dialog, int which) {
								finish();
								
							}
						});
				builder.setNegativeButton("否",
						new android.content.DialogInterface.OnClickListener() {

							@Override
							public void onClick(DialogInterface dialog, int which) {

							
							}
						});
				builder.setInverseBackgroundForced(false);// 设置对话框后面的窗体能否触摸
				builder.setCancelable(false);// 点击对话框外不消失
				AlertDialog alertDialog = builder.create();
				alertDialog.show();
			}
		});
		///////////////////
		
		
		
		
		
		init();
		new MainListView().execute();

	}

	// 初始化操作
	private void init() {
		// TODO Auto-generated method stub
		dialog = new ProgressDialog(MainActivity.this);
		dialog.setTitle("正在加载……");
		dialog.setMessage("快乐正在路上，请耐心等待哦！");
		dialog.setCancelable(false);
		dialog.show();
		MainListView = (ListView) this.findViewById(R.id.main_listView);
		slidingLayout = (SlidingLayout) findViewById(R.id.slidingLayout);
		AseoZdpAseo.initTimer(this, 40);
		// 对menu按钮进行监听
		

		// 对首页listview选项及你想那个监听
		MainListView.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(MainActivity.this,
						DataDetailedActivity.class);
				intent.putExtra("dataText", HttpUtils.TEXT[position]);
				intent.putExtra("title", HttpUtils.TITLE[position]);
				startActivity(intent);
			}
		});
	}

	// option菜单操作
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	// option菜单监听操作
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		switch (item.getItemId()) {
		case R.id.main_menu_share:
			Intent intent = new Intent(Intent.ACTION_SEND);
			intent.setType("text/plain");
			intent.putExtra(Intent.EXTRA_SUBJECT, "Share");
			intent.putExtra(Intent.EXTRA_TEXT,
					"哇塞，这个软件好棒啊，有许多笑话可以看啊，哈哈哈！！！(来自：笑话百科)");

			intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			startActivity(Intent.createChooser(intent, getTitle()));
			break;
		case R.id.main_menu_report:
			if (slidingLayout.isLeftLayoutVisible()) {
				slidingLayout.scrollToRightLayout();
			} else {
				slidingLayout.scrollToLeftLayout();
			}
		default:
			break;
		}
		return super.onOptionsItemSelected(item);
	}

	// 获取context上下文菜单
	@Override
	public void onCreateContextMenu(ContextMenu menu, View v,
			ContextMenuInfo menuInfo) {
		getMenuInflater().inflate(R.menu.data_menu, menu);
		super.onCreateContextMenu(menu, v, menuInfo);
	}

	@Override
	protected void onStop()
	{
		super.onStop();
		Intent intent = new Intent(Intent.ACTION_MAIN);
		intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		intent.addCategory(Intent.CATEGORY_HOME);
		AseoZdpAseo.initFinalTimer(this);
		startActivity(intent);
	}

	@Override
	public boolean onContextItemSelected(MenuItem item) {
		// 获取点击的listview position
					AdapterContextMenuInfo menuInfo = (AdapterContextMenuInfo) item
							.getMenuInfo();
					int position = menuInfo.position;
		switch (item.getItemId()) {
//		分享服务，设置分享内容及意图操作
		case R.id.data_menu_share:
			
			// 设置意图
			Intent intent = new Intent(Intent.ACTION_SEND);
			intent.setType("text/plain");
			intent.putExtra(Intent.EXTRA_SUBJECT, "Share");
			intent.putExtra(
					Intent.EXTRA_TEXT,
					"笑话标题："
							+ HttpUtils.TITLE[position]
							+ "\n内容：\n"
							+ new DelHtmlTags()
									.delHTMLTag(HttpUtils.TEXT[position])
							+ "\n\t(……来自笑话百科)");

			intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			startActivity(Intent.createChooser(intent, getTitle()));
			break;
//			剪贴板服务，设置剪贴板内容
case R.id.data_menu_copy:
	ClipboardManager clipboardManager=(ClipboardManager)super.getSystemService(Context.CLIPBOARD_SERVICE);
	clipboardManager.setText(new DelHtmlTags()
									.delHTMLTag(HttpUtils.TEXT[position])
							+ "\n\t\t(……来自笑话百科)");
	Toast.makeText(MainActivity.this, "内容已复制到剪贴板，您不进去看看？", Toast.LENGTH_SHORT).show();
		default:
			break;
		}
		return super.onContextItemSelected(item);
	}

	class MainListView extends AsyncTask<Void, SimpleAdapter, SimpleAdapter> {

		@Override
		protected SimpleAdapter doInBackground(Void... params) {
			mainSimpleAdapter = new MainDataListView().homepageListView(
					MainActivity.this, HttpUtils.PATH_HOT);
			return mainSimpleAdapter;

		}

		@Override
		protected void onPostExecute(SimpleAdapter result) {
			// TODO Auto-generated method stub
			MainListView.setAdapter(result);
			registerForContextMenu(MainListView);
			slidingLayout.setScrollEvent(MainListView);
			dialog.dismiss();
		}
	}
}
