package com.flyou.qiubai.Vo;

public class WebData {
private String tilele;
private String see_num;
private String date;
private String content_link;
public String getTilele() {
	return tilele;
}
public void setTilele(String tilele) {
	this.tilele = tilele;
}
public String getSee_num() {
	return see_num;
}
public void setSee_num(String see_num) {
	this.see_num = see_num;
}
public String getDate() {
	return date;
}
public void setDate(String date) {
	this.date = date;
}
public String getContent_link() {
	return content_link;
}
public void setContent_link(String content_link) {
	this.content_link = content_link;
}
@Override
public String toString() {
	return "Main_List_data [tilele=" + tilele + ", see_num=" + see_num
			+ ", date=" + date + ", content_link=" + content_link + "]";
}
public WebData(String tilele, String see_num, String date,
		String content_link) {
	super();
	this.tilele = tilele;
	this.see_num = see_num;
	this.date = date;
	this.content_link = content_link;
}

}
